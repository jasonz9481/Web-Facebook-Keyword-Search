<?php
/**
 * Created by PhpStorm.
 * User: xiangjun
 * Date: 2017/3/28
 * Time: 16:23
 */
date_default_timezone_set('America/Los_Angeles');
header("content-type:text/html; charset=utf-8;Access-Control-Allow-Origin: *");
//define('FACEBOOK_SDK_V4_SRC_DIR', __DIR__ . '/php-graph-sdk-5.0.0/src/Facebook/');
//require_once __DIR__ . '/php-graph-sdk-5.0.0/src/Facebook/autoload.php';
//
//$fb = new Facebook\Facebook([
//    'app_id' => '173817123122342',
//    'app_secret' => 'f1157659ad69afd90004068afac68cd1',
//    'default_graph_version' => 'v2.8',
//]);

if(isset($_GET["callFunc"])){
    if($_GET["callFunc"] == "facebookAPI"){
        facebookAPI();
    }elseif ($_GET["callFunc"] == "getNextOrPrevious"){
        getNextOrPrevious();
    }elseif ($_GET["callFunc"] == "getDetails"){
        getDetails();
    }elseif ($_GET["callFunc"] == "getRealPicture"){
        getRealPicture();
    }
}else{
    echo "haha";
}


function facebookAPI(){
    global $fb;
    $keyword = "";
    $type = "";
    if(isset($_GET["keyword"])){
        $keyword = $_GET["keyword"];
    }
    if(isset($_GET["type"])){
        $type = $_GET["type"];

    }
    $accessToken = "EAACeFfPhLKYBAG6CtOEMszb2AHFmdyoThX0yCCRvlsVWjhGt8YQVeiAbTRH2PjHwaY9GExfnG6oKsGuae05t7LCBZAZCQQZBoiYhsLCT0EDcY3nNT3SFH8Psd80JZC3kDbHOmc0bfCHG9V8g3S3KXWolLHUeJp8ZD";
    if(is_numeric(trim($keyword))) {
        echo "Keyword cannot be a number!";
    }else{

        $URL = "https://graph.facebook.com/v2.8/search?q=".str_replace(" ","+",$keyword)."&type=".$type."&fields=id,name,picture.width(700).height(700)";

        if($type == "place"){
            $latitude = $_GET["latitude"];
            $longtitude = $_GET["longtitude"];
            $distance = $_GET["distance"];
            $URL.="&center=".$latitude.",".$longtitude."&distance=".$distance;
        }
        $URL.="&access_token=".$accessToken;
        $URL = trim($URL);
        $content=file_get_contents($URL);
//        $content=$fb->get($URL, $accessToken);
//        $content = $content->getBody();
        echo $content;
    }
}

function getNextOrPrevious(){
    if(isset($_GET["URL"])){
        $URL = $_GET["URL"];
        $content=file_get_contents($URL);
//        var_dump($content);
        echo $content;
    }
}

function getDetails(){
//    global $fb;
    if(isset($_GET["id"])){
        $id = $_GET["id"];
        $accessToken = "EAACeFfPhLKYBAG6CtOEMszb2AHFmdyoThX0yCCRvlsVWjhGt8YQVeiAbTRH2PjHwaY9GExfnG6oKsGuae05t7LCBZAZCQQZBoiYhsLCT0EDcY3nNT3SFH8Psd80JZC3kDbHOmc0bfCHG9V8g3S3KXWolLHUeJp8ZD";
        $URL = "https://graph.facebook.com/v2.8/".$id."?fields=id,name,picture.width(700).height(700),albums.limit(5){name,photos.limit(2){name,picture}},posts.limit(5){created_time,picture,name,message,story}&access_token=".$accessToken;
        $URL = trim($URL);
        $content=file_get_contents($URL);
//        $content=$fb->get($URL, $accessToken);
//        $content = $content->getBody();
        echo $content;
    }
}

function getRealPicture(){
    if(isset($_GET["pictureId"])){
        $pictureId = $_GET["pictureId"];
        $accessToken = "EAACeFfPhLKYBAG6CtOEMszb2AHFmdyoThX0yCCRvlsVWjhGt8YQVeiAbTRH2PjHwaY9GExfnG6oKsGuae05t7LCBZAZCQQZBoiYhsLCT0EDcY3nNT3SFH8Psd80JZC3kDbHOmc0bfCHG9V8g3S3KXWolLHUeJp8ZD";
        $URL = "https://graph.facebook.com/v2.8/".$pictureId."/picture?redirect=false&access_token=".$accessToken;
        $URL = trim($URL);
        $content=file_get_contents($URL);
        echo $content;
    }
}

?>