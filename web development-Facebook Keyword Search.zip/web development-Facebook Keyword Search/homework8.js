/**
 * Created by xiangjun on 2017/3/28.
 */
var hasClickedSearchButton = false
function clickNavBar(id) {

    var oldActive = document.getElementsByClassName("active")[0];
    oldActive.setAttribute("class","");
    oldActive.setAttribute("style","");

    var newActive = document.getElementById(id);
    newActive.style = "color: ghostwhite;background: darkblue;";
    newActive.className = "active";

    if(hasClickedSearchButton){
        search();
    }
}

function reset() {
    $("#inputText").val("");
    $("#detailsDiv").html("");
    $(".down").html("");
}

function setFavourite(i,id,selectedRecords,isInMain) {
    // console.log(selectedRecords);
    if(isInMain){
        var originalClass = $("#setFavourite"+i+"inMain").attr('class');
        if (typeof(Storage) === "undefined") {
            alert("sorry,your browser does not support local storage!");
            return;
        }
        if(originalClass === "glyphicon glyphicon-star-empty"){
            $("#setFavourite"+i+"inMain").attr('class',"glyphicon glyphicon-star");
            $("#setFavourite"+i+"inMain").attr('style',"color: rgb(255, 215, 0);");

            var keyName = String(id);

            localStorage.setItem(keyName,JSON.stringify(selectedRecords));

        }else{
            $("#setFavourite"+i+"inMain").attr('class',"glyphicon glyphicon-star-empty");
            $("#setFavourite"+i+"inMain").attr('style',"");
            var keyName = String(id);
            localStorage.removeItem(keyName);
        }
    }else{
        var originalClass = $("#setFavourite"+i).attr('class');
        if (typeof(Storage) === "undefined") {
            alert("sorry,your browser does not support local storage!");
            return;
        }
        if(originalClass === "glyphicon glyphicon-star-empty"){
            $("#setFavourite"+i).attr('class',"glyphicon glyphicon-star");
            $("#setFavourite"+i).attr('style',"color: rgb(255, 215, 0);");

            var keyName = String(id);

            localStorage.setItem(keyName,JSON.stringify(selectedRecords));

        }else{
            $("#setFavourite"+i).attr('class',"glyphicon glyphicon-star-empty");
            $("#setFavourite"+i).attr('style',"");
            var keyName = String(id);
            localStorage.removeItem(keyName);
        }
    }

}

function showFavourites() {
    $("#out").click();
    var oldActive = document.getElementsByClassName("active")[0];
    oldActive.setAttribute("class","");
    oldActive.setAttribute("style","");

    var newActive = document.getElementById("favourite");
    newActive.style = "color: ghostwhite;background: darkblue;";
    newActive.className = "active";

    var htmlStr = "<table class='table table-hover'>";
    htmlStr += "<thead>";
    htmlStr += "<tr>";
    htmlStr += "<th>#</th>";
    htmlStr += "<th>Profile photo</th>";
    htmlStr += "<th>Name</th>";
    htmlStr += "<th>Type</th>";
    htmlStr += "<th>Favourite</th>";
    htmlStr += "<th>Details</th>";
    htmlStr += "</tr>";
    htmlStr += "</thead>";
    htmlStr += "<tbody id='favouriteBody'>";


    var i = 0;
    for(var key in localStorage){
        // if(key !== "key"){
        var data = localStorage.getItem(key);
        if(data === null || data.length === 0){
            continue;
        }
        // console.log(data);
        var decodedData = JSON.parse(data);
        // console.log(decodedData);
        var pictureURL = decodedData.pictureURL;
        var name = decodedData.name.replace("%","'");
        var type = decodedData.type;
        var id = decodedData.id;


        htmlStr += "<tr>";
        htmlStr += "<td style='vertical-align: middle'>"+(i+1)+"</td>";
        htmlStr += "<td style='vertical-align: middle'><img id='img"+(i+1)+"'src='"+pictureURL+"' width='40px' height='40px' class='img-circle'></td>";
        htmlStr += "<td style='vertical-align: middle'><div id='name"+(i+1)+"'>"+name+"</div></td>";
        htmlStr += "<td style='vertical-align: middle'><div id='type"+(i+1)+"'>"+type+"</div></td>";
        htmlStr += "<td style='vertical-align: middle'><button class='btn btn-default' onclick='deleteFavourite("+key+")'><span id = 'deleteFavourite"+(i+1)+"' class='glyphicon glyphicon-trash'></span></button></td>";
        htmlStr += "<td style='vertical-align: middle'><button class='btn btn-default'  onclick='getDetails("+i+","+id+")'><span class='glyphicon glyphicon-chevron-right'></span></button></td>";
        htmlStr += "</tr>";
        i++;
        // }
    }
    htmlStr += "</tbody>";
    htmlStr += "</table>";

    htmlStr += "<br>";
    htmlStr += "<br>";
    if(i>0){

        $(".down").html(htmlStr);
        $(".down").attr("style","visibility:visible");
    }else{
        alert("no favourites items!");
        $(".down").html("");
        $(".down").attr("style","visibility:visible");
    }

}

function deleteFavourite(key) {
    localStorage.removeItem(key);
    showFavourites();
}




var latitude = 0;
var longtitude = 0;
var distance = 0;

function getLocation() {
    var options = {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
    };
    function success(pos) {
        var crd = pos.coords;
        flag = true;
        latitude = crd.latitude;
        longtitude = crd.longitude;
        distance = crd.accuracy;
    };

    function error(err) {
        alert("error" + err.code+":"+err.message);
    };

    navigator.geolocation.getCurrentPosition(success, error, options);
}

function search() {
    hasClickedSearchButton = true;

    $("#out").click();
    // $("#detailsDiv").html("");

    var keyword = $("#inputText").val();
    if(keyword !== "" ){

        var progressStr = callProgressBar();
        $(".down").html(progressStr);

        var type = $(".active").attr('id');
        if(type === "place"){
            $.ajax({
                // url:"https://helloworld-162106.appspot.com/homework8.php",
                url:"homework8.php",
                data:{callFunc:"facebookAPI",keyword:keyword,type:type,latitude:latitude,longtitude:longtitude,distance:distance},
                type:"GET",
                success:function (result) {
                    try{

                        var parsedResult = JSON.parse(result);
                        var htmelStr = analyzeResult(parsedResult);
                        $("#detailsDiv").html("");
                        $(".down").html(htmelStr);
                        $(".down").attr("style","visibility:visible");
                    }catch (e){

                        alert("there is a problem while parsing the json:"+e);
                    }
                },
                error:function (response) {
                    alert("error");
                    console.log(response);
                    $("#detailsDiv").html("");
                    $(".down").html("");
                }
            });
        }else if(type === "favourite"){
            showFavourites();
        }else{
            // $("#table").css('visibility','visible');
            $.ajax({
                url:"homework8.php",
                data:{callFunc:"facebookAPI",keyword:keyword,type:type},
                type:"GET",
                success:function (result) {
                    // console.log(result);
                    try{

                        var parsedResult = JSON.parse(result);
                        var htmelStr = analyzeResult(parsedResult);
                        $("#detailsDiv").html("");
                        $(".down").html(htmelStr);
                        $(".down").attr("style","visibility:visible");
                    }catch (e){
                        alert("there is a problem while parsing the json:"+e);
                    }
                },
                error:function (response) {

                    alert("error");
                    console.log(response);
                    $("#detailsDiv").html("");
                    $(".down").html("");
                }
            });
        }
    }
}

function callProgressBar() {
    var str = "<table style='width: 100%;height: 50%'>";
        str += "<tr>";
            str += "<td style='vertical-align: middle'>";
                str += " <center>";
                    str += "<div class='progress' style='width: 80%'>";
                        str += "<div class='progress-bar progress-bar-striped active' role='progressbar' aria-valuenow='50' aria-valuemin='0' aria-valuemax='100' style='width:50%'>";
                        str += "</div>";
                    str += "</div>";
                str += "</center>";
            str += "</td>";
        str += "</tr>";
        str += "</table>";
    return str;
}


function analyzeResult(responseJSON) {
    var htmlStr = "<table class='table table-hover'>";
    htmlStr += "<thead>";
        htmlStr += "<tr>";
            htmlStr += "<th>#</th>";
            htmlStr += "<th>Profile photo</th>";
            htmlStr += "<th>Name</th>";
            htmlStr += "<th>Favourite</th>";
            htmlStr += "<th>Details</th>";
        htmlStr += "</tr>";
    htmlStr += "</thead>";
    htmlStr += "<tbody>";

        var data = responseJSON.data;

        // console.log(responseJSON);
        var type = $(".active").attr("id");
        for(var i=0;i<data.length;i++){
            var pictureData = data[i].picture.data;
            // console.log(data[i].picture);
            var pictureURL = pictureData.url;
            var name = data[i].name;
            var id = data[i].id;

            var fItemInfo = {};
            fItemInfo["pictureURL"] = pictureURL;
            fItemInfo["name"] = name.replace("'","%");
            fItemInfo["type"] = type;
            fItemInfo["id"] = id;
            var fItemInfoJSONStr = JSON.stringify(fItemInfo);

            htmlStr += "<tr>";
                htmlStr += "<td style='vertical-align: middle'>"+(i+1)+"</td>";
                htmlStr += "<td style='vertical-align: middle'><img id='img"+(i+1)+"'src='"+pictureURL+"' width='40px' height='40px' class='img-circle'></td>";
                htmlStr += "<td style='vertical-align: middle'><div id='name"+(i+1)+"'>"+name+"</div></td>";
                if(localStorage.getItem(id) !== null && localStorage.getItem(id).length !== 0){
                    htmlStr += "<td style='vertical-align: middle'><button class='btn btn-default' onclick='setFavourite("+( i+1)+","+id+","+fItemInfoJSONStr+",true)'><span id = 'setFavourite"+(i+1)+"inMain' class='glyphicon glyphicon-star' style='color: rgb(255, 215, 0);'></span></button></td>";
                }else{
                    htmlStr += "<td style='vertical-align: middle'><button class='btn btn-default' onclick='setFavourite("+(i+1)+","+id+","+fItemInfoJSONStr+",true)'><span id = 'setFavourite"+(i+1)+"inMain' class='glyphicon glyphicon-star-empty'></span></button></td>";
                }
                htmlStr += "<td style='vertical-align: middle'><button class='btn btn-default' onclick='getDetails("+i+","+id+","+fItemInfoJSONStr+")'><span class='glyphicon glyphicon-chevron-right'></span></td>";
            htmlStr += "</tr>";
        }
    htmlStr += "</tbody>";
    htmlStr += "</table>";

    if(responseJSON.hasOwnProperty("paging")){
        if(responseJSON.paging.hasOwnProperty("next")){
            var next = responseJSON.paging.next;
            htmlStr += "<div class='container'>";
            htmlStr += "<div class='row'>";
            htmlStr += "<center>";
            if(responseJSON.paging.hasOwnProperty('previous')){
                var previous = responseJSON.paging.previous;
                htmlStr += "<div style='display:inline-block;margin-right: 30px;width: 100px'>";
                htmlStr += "<button type='button' class='btn btn-default btn-block' onclick='getNextOrPrevious(\""+previous+"\")' >Previous</button>";
                htmlStr += "</div>";
            }
            htmlStr += "<div style='display:inline-block;width: 100px'>";
            htmlStr += "<button type='button' class='btn btn-default btn-block' onclick='getNextOrPrevious(\""+next+"\")' >Next</button>";
            htmlStr += "</div>";
            htmlStr += "</center>";
            htmlStr += "</div>";
            htmlStr += "</div>";
        }
    }


    htmlStr += "<br>";
    htmlStr += "<br>";
    return htmlStr;
}

function getNextOrPrevious(url) {

    $.ajax({
        url:"homework8.php",
        data:{callFunc:"getNextOrPrevious",URL:url},
        type:"GET",
        success:function (result) {
            try{
                var parsedResult = JSON.parse(result);
                var htmelStr = analyzeResult(parsedResult);
                $(".down").html(htmelStr);
            }catch (e){
                alert("there is a problem while parsing the json:"+e);
            }
        },
        error:function () {
            alert("error");
        }
    });
}

function getDetails(i,id,selectedSTR) {
    // console.log(selectedSTR);
    var htmlStr="";
    //head
    htmlStr += "<div class='container'>";
    htmlStr += "<div class='row'>";
    htmlStr += "<div class='col-xs-1'>";
    if($(".active").attr("id") === "favourite"){
        htmlStr += "<button class='btn btn-default' onclick='back("+id+","+(i+1)+",true)'><span class='glyphicon glyphicon-chevron-left'>Back</span></button>";
    }else{
        htmlStr += "<button class='btn btn-default' onclick='back("+id+","+(i+1)+",false)'><span class='glyphicon glyphicon-chevron-left'>Back</span></button>";
    }
    htmlStr += "</div>";
    // htmlStr += "<div class='col-sm-2 col-sm-offset-9' >";
    htmlStr += "<div id='favBtn' class='col-xs-1'>";
    if(localStorage.getItem(id) !== null && localStorage.getItem(id).length !== 0){
        htmlStr += "<button class='btn btn-default' style='margin-right: 30px' onclick='setFavourite("+(i+1)+","+id+","+JSON.stringify(selectedSTR)+",false)'><span id = 'setFavourite"+(i+1)+"' class='glyphicon glyphicon-star' style='color: rgb(255, 215, 0);'></span></button>";
    }else{
        htmlStr += "<button class='btn btn-default' style='margin-right: 30px' onclick='setFavourite("+(i+1)+","+id+","+JSON.stringify(selectedSTR)+",false)'><span id = 'setFavourite"+(i+1)+"' class='glyphicon glyphicon-star-empty'></span></button>";
    }
    htmlStr += "</div>";
    htmlStr += "<div id='fbBtn' class='col-xs-1'>";
        htmlStr += "<button class='btn btn-default' onclick='postFacebook("+JSON.stringify(selectedSTR)+")'><img src='http://cs-server.usc.edu:45678/hw/hw8/images/facebook.png' width='20px' height='20px' ></button>";
    htmlStr += "</div>";
    // htmlStr += "</div>";
    htmlStr += "</div>";
    htmlStr += "</div>";
    htmlStr += "<br>";
    htmlStr += "<div class='container'>";
    htmlStr += "<div class='row'>";
    htmlStr += "<div class='col-md-6'>";
    htmlStr += "<table class='table table-bordered'>";
    htmlStr += "<thead style='background: whitesmoke;'>";
    htmlStr += "<tr>";
    htmlStr += "<th>Albums</th>";
    htmlStr += "</tr>";
    htmlStr += "</thead>";
    htmlStr += "<tbody id='albumsBody'>";
    htmlStr += "<tr>";
    htmlStr += "<td style='height: 100px;width:100%;vertical-align: middle'>";
    htmlStr += callProgressBar()
    htmlStr += "</td>";
    htmlStr += "</tr>";
    htmlStr += "</tbody>";
    htmlStr += "</table>";
    htmlStr += "</div>";

    htmlStr += "<div class='col-md-6'>";
    htmlStr += "<table class='table table-bordered'>";
    htmlStr += "<thead style='background: whitesmoke'>";
    htmlStr += "<tr>";
    htmlStr += "<th>Posts</th>";
    htmlStr += "</tr>";
    htmlStr += "</thead>";
    htmlStr += "<tbody id='postsBody'>";
    htmlStr += "<tr>";
    htmlStr += "<td style='height: 100px;width:100%;vertical-align: middle'>";
    htmlStr += callProgressBar();
    htmlStr += "</td>";
    htmlStr += "</tr>";
    htmlStr += "</tbody>";
    htmlStr += "</table>";
    htmlStr += "</div>";
    htmlStr += "</div>";
    htmlStr += "</div>";

    // $(".down").html("");
    $(".down").attr("style","visibility:collapse");
    $("#detailsDiv").html(htmlStr);
    $("#enter").click();


    $.ajax({
        url:"homework8.php",
        data:{callFunc:"getDetails",id:id},
        type:"GET",
        success:function (result) {
            try{

                var parsedResult = JSON.parse(result);
                console.log(parsedResult);
                analyzeResultForDetails(parsedResult);
            }catch (e){
                var nodataStr = "";
                nodataStr += "<tr>";
                nodataStr += "<td style='height: 100px;width:100%;vertical-align: middle'>";
                nodataStr += "<div style='height: 45px; width:100%;background: lightyellow;border: 1px solid cornsilk;display: table'>";
                nodataStr += "<div style='display:table-cell;vertical-align: middle;border-radius: 3px;'>No data found</div>";
                nodataStr += "</div>";
                nodataStr += "</td>";
                nodataStr += "</tr>";
                $("#albumsBody").html(nodataStr);

                nodataStr = "";
                nodataStr += "<tr>";
                nodataStr += "<td style='height: 90px;width:100%;vertical-align: middle'>";
                nodataStr += "<div style='height: 45px; width:100%;background: lightyellow;border: 1px solid cornsilk;display: table'>";
                nodataStr += "<div style='display:table-cell;vertical-align: middle;border-radius: 3px;'>No data found</div>";
                nodataStr += "</div>";
                nodataStr += "</td>";
                nodataStr += "</tr>";
                $("#postsBody").html(nodataStr);
            }



            // console.log(result);
        },
        error:function () {
            alert("error");
        }
    });
}

function back(id,i,isFavouriteTab) {
    $("#out").click();
    // $("#detailsDiv").attr("style","visibility:collapse");
    $(".down").attr("style","visibility:visible");
    if(isFavouriteTab){
        var htmlStr = "";
        var i = 0;
        for(var key in localStorage){
            var data = localStorage.getItem(key);
            if(data === null || data.length === 0){
                continue;
            }
            // console.log(data);
            var decodedData = JSON.parse(data);
            // console.log(decodedData);
            var pictureURL = decodedData.pictureURL;
            var name = decodedData.name.replace("%","'");
            var type = decodedData.type;
            var id = decodedData.id;


            htmlStr += "<tr>";
            htmlStr += "<td style='vertical-align: middle'>"+(i+1)+"</td>";
            htmlStr += "<td style='vertical-align: middle'><img id='img"+(i+1)+"'src='"+pictureURL+"' width='40px' height='40px' class='img-circle'></td>";
            htmlStr += "<td style='vertical-align: middle'><div id='name"+(i+1)+"'>"+name+"</div></td>";
            htmlStr += "<td style='vertical-align: middle'><div id='type"+(i+1)+"'>"+type+"</div></td>";
            htmlStr += "<td style='vertical-align: middle'><button class='btn btn-default' onclick='deleteFavourite("+key+")'><span id = 'deleteFavourite"+(i+1)+"' class='glyphicon glyphicon-trash'></span></button></td>";
            htmlStr += "<td style='vertical-align: middle'><button class='btn btn-default'  onclick='getDetails("+i+","+id+")'><span class='glyphicon glyphicon-chevron-right'></span></button></td>";
            htmlStr += "</tr>";
            i++;
        }
        if(i>0){
            $("#favouriteBody").html(htmlStr);
        }else{
            $(".down").html("");
        }
    }else{
        if(localStorage.getItem(id) !== null && localStorage.getItem(id).length !== 0){
            $("#setFavourite"+i+"inMain").attr('class',"glyphicon glyphicon-star");
            $("#setFavourite"+i+"inMain").attr('style',"color: rgb(255, 215, 0);");
        }else{
            $("#setFavourite"+i+"inMain").attr('class',"glyphicon glyphicon-star-empty");
            $("#setFavourite"+i+"inMain").attr('style',"");
        }
    }
}

function analyzeResultForDetails(parsedResult) {

    var htmlStr = "";
    if(!parsedResult.hasOwnProperty("albums")){
        htmlStr += "<tr>";
        htmlStr += "<td style='height: 100px;width:100%;vertical-align: middle'>";
        htmlStr += "<div style='height: 45px; width:100%;background: lightyellow;border: 1px solid cornsilk;display: table'>";
        htmlStr += "<div style='display:table-cell;vertical-align: middle;border-radius: 3px;'>No data found</div>";
        htmlStr += "</div>";
        htmlStr += "</td>";
        htmlStr += "</tr>";
    }else{
        var albums = parsedResult.albums;
        if(albums.hasOwnProperty("data")){
            var albumsData = albums.data;
            htmlStr += "<tr>";
            htmlStr += "<td>";
            htmlStr += "<div class='panel-group' id='accordion' role='tablist' aria-multiselectable='true'>";


            for(var j=0;j<albumsData.length;j++){
                var albumName = albumsData[j].name;
                htmlStr += "<div class='panel panel-default'>";
                    htmlStr += "<div class='panel-heading' role='tab' id='heading"+(j+1)+"'>";
                        htmlStr += "<h2 class='panel-title'>";
                            htmlStr += "<a href='#albums"+(j+1)+"' role='button' data-toggle = 'collapse' data-parent='#accordion' aria-expanded='false' aria-controls='albums"+(j+1)+"'>"+albumName+"</a>";
                        htmlStr += "</h2>";
                    htmlStr += "</div>";
                if(albumsData[j].hasOwnProperty("photos")){
                    var photos = albumsData[j].photos;
                    if(photos.hasOwnProperty("data")){
                        var photosData = photos.data;
                        htmlStr += "<div class='panel-collapse collapse";
                        if(j === 0){
                            htmlStr += " in";
                        }
                        htmlStr += "' id='albums"+(j+1)+"' role='tabpanel' aria-labelledby='heading"+(j+1)+"'>";
                        htmlStr += "<div class='panel-body'>";
                        for(var k=0;k<photosData.length;k++){
                            if(photosData[k].hasOwnProperty("picture")){
                                var pictureid = photosData[k].id;
                                getRealPicture(pictureid);
                                htmlStr+="<img id="+pictureid+" src='' width='400px' height='300px' class='img-rounded'><br><br>";
                            }

                        }
                        htmlStr += "</div>";
                        htmlStr += "</div>";
                    }
                }
                htmlStr += "</div>";


            }
            htmlStr += "</div>";
            htmlStr += "</td>";
            htmlStr += "</tr>";
        }

    }
    $("#albumsBody").html(htmlStr);

    htmlStr="";
    if(!parsedResult.hasOwnProperty("posts")){
        htmlStr += "<tr>";
        htmlStr += "<td style='height: 90px;width:100%;vertical-align: middle'>";
        htmlStr += "<div style='height: 45px; width:100%;background: lightyellow;border: 1px solid cornsilk;display: table'>";
        htmlStr += "<div style='display:table-cell;vertical-align: middle;border-radius: 3px;'>No data found</div>";
        htmlStr += "</div>";
        htmlStr += "</td>";
        htmlStr += "</tr>";
    }else{
        var posts = parsedResult.posts;
        // console.log(posts);
        if(posts.hasOwnProperty("data")){
            var postsData = posts.data;
            for(var j=0;j<postsData.length;j++){
                var postName = postsData[j].name;
                var thumbnail = postsData[j].picture;
                var createdTime = postsData[j].created_time;
                var message = "";
                if(postsData[j].hasOwnProperty("message")){
                    message = postsData[j].message;
                }else if(postsData[j].hasOwnProperty("story")){
                    message = postsData[j].story
                }
                htmlStr += "<tr>";
                htmlStr += "<td style='border: 0px'>";
                htmlStr += "<div class='container' style='padding-top:3%;padding-bottom:3%;width:100%;border-radius: 3px;border: 1px solid whitesmoke'>";
                htmlStr += "<div class='row' style='width: 100%;'>";
                htmlStr += "<div class='col-sm-1'>";
                htmlStr += "<img src='"+thumbnail+"' width='40px' height='40px'>";
                htmlStr += "</div>";
                htmlStr += "<div class='col-sm-5' style='margin-left: 3%'>";
                htmlStr += "<div class='col-xs-16'>";
                htmlStr += postName;
                htmlStr += "</div>";
                htmlStr += "<div class='col-xs-16'style='color:gray;padding-top: 3%'>";
                htmlStr += moment(createdTime).format("YYYY-MM-DD h:mm:ss");
                htmlStr += "</div>";
                htmlStr += "</div>";
                htmlStr += "</div>";
                htmlStr += "<div class='row' style='width: 100%;padding-top: 3%'>";
                htmlStr += "<div class='col-md-12'>";
                htmlStr += message;
                htmlStr += "</div>";
                htmlStr += "</div>";
                htmlStr += "</div>";
                htmlStr += "</td>";
                htmlStr += "</tr>";
            }
        }
    }
    $("#postsBody").html(htmlStr);
}

function getRealPicture(pictureid) {
    $.ajax({
        url:"homework8.php",
        data:{callFunc:"getRealPicture",pictureId:pictureid},
        type:"GET",
        success:function (result) {
            try{
                var parsedResult = JSON.parse(result);
                if(parsedResult.hasOwnProperty("data")) {
                    var data = parsedResult.data;
                    if (data.hasOwnProperty("url")) {
                        $("#"+pictureid).attr("src",data.url);
                    }
                }

            }catch (e){
                alert("there is a problem while parsing the json:"+e);
            }
        },
        error:function () {
            alert("error");
        }
    });
}


window.fbAsyncInit = function() {
    FB.init({
        appId      : '173817123122342',
        xfbml      : true,
        version    : 'v2.8'
    });
    FB.AppEvents.logPageView();
};

(function(d, s, id){
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {return;}
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

function postFacebook(selectedSTR) {
    FB.ui({
        app_id: '173817123122342',
        method: 'feed',
        link: window.location.href,
        picture: selectedSTR.pictureURL,
        name: selectedSTR.name,
        caption: "FB SEARCH FROM USC CSCI571"
    }, function(response){
        if (response && !response.error_message)
            alert("Posted Successfully");
        else
            alert("Not Posted");
    });
}