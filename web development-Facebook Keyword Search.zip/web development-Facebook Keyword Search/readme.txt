This is a readme file

1.this system will call Facebook API, so you should make sure that you can connect to the facebook.com
2.you should first put the php file on the web server on your computer, and run it.
3.then run index.html, and type some keywords, and then it will show the result using bootstrap.

Or you can just type the URL below:
http://helloworld-163823.appspot.com/